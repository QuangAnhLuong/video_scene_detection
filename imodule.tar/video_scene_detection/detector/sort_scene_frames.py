INPUT_FILE = "results/scene_changes.txt"
OUTPUT_FILE = "results/sorted_frames.txt"

frames = []

with open(INPUT_FILE, "r") as f:
    for line in f:
        frame, diff = line.split()
        frames.append((frame, float(diff)))

frames.sort(key=lambda x: x[1], reverse=True)

with open(OUTPUT_FILE, "w") as f:
    for frame, diff in frames:
        line = f"{frame} {diff:.6f}"
        print(line)
        f.write(line + "\n")

print(f"[+] Saved sorted frames to {OUTPUT_FILE}")
