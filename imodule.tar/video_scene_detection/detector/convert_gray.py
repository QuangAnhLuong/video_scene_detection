import cv2
import os

INPUT_DIR = "frames"
OUTPUT_DIR = "gray_frames"

os.makedirs(OUTPUT_DIR, exist_ok=True)

files = sorted(os.listdir(INPUT_DIR))

for file in files:

    if not file.endswith(".png"):
        continue

    img_path = os.path.join(INPUT_DIR, file)

    img = cv2.imread(img_path)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    out_name = file.replace("frame", "gray")

    out_path = os.path.join(OUTPUT_DIR, out_name)

    cv2.imwrite(out_path, gray)

    print(f"[+] Saved {out_path}")

print("[+] Convert completed")
