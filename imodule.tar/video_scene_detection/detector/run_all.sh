#!/bin/bash

echo "[1] Extract frames"
python3 extract_frames.py

echo "[2] Convert to gray"
python3 convert_gray.py

echo "[3] Compute histogram"
python3 compute_histogram.py

echo "[4] Compare histogram"
python3 compare_histogram.py

echo "[5] Detect scene change"
python3 detect_scene_change.py

echo "[6] Threshold experiment"
python3 threshold_experiment.py

echo "[7] Sort scene frames"
python3 sort_scene_frames.py

echo "[+] Done"
