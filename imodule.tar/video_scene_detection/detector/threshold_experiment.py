INPUT_FILE = "results/histogram_differences.txt"
OUTPUT_FILE = "results/threshold_result.txt"

thresholds = [0.2, 0.4, 0.6, 0.8]

data = []

with open(INPUT_FILE, "r") as f:
    for line in f:
        frame, diff = line.split()
        data.append((frame, float(diff)))

with open(OUTPUT_FILE, "w") as out:
    for threshold in thresholds:
        count = 0

        for frame, diff in data:
            if diff > threshold:
                count += 1

        line = f"Threshold {threshold}: detected {count} scene change frames"
        print(line)
        out.write(line + "\n")

print(f"[+] Saved threshold experiment to {OUTPUT_FILE}")
