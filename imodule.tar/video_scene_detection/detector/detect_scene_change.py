THRESHOLD = 0.45

INPUT_FILE = "results/histogram_differences.txt"
OUTPUT_FILE = "results/scene_changes.txt"

scene_changes = []

with open(INPUT_FILE, "r") as f:
    for line in f:
        frame, diff = line.split()
        diff = float(diff)

        if diff > THRESHOLD:
            scene_changes.append((frame, diff))
            print(f"[SCENE CHANGE] {frame} D_hist={diff:.6f}")

with open(OUTPUT_FILE, "w") as f:
    for frame, diff in scene_changes:
        f.write(f"{frame} {diff:.6f}\n")

print(f"[+] Threshold = {THRESHOLD}")
print(f"[+] Total scene changes: {len(scene_changes)}")
print(f"[+] Saved to {OUTPUT_FILE}")
