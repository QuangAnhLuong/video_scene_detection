import cv2
import os

VIDEO_PATH = "input_video.mp4"
OUTPUT_DIR = "frames"

os.makedirs(OUTPUT_DIR, exist_ok=True)

video = cv2.VideoCapture(VIDEO_PATH)

if not video.isOpened():
    print("[-] Cannot open video")
    exit(1)

count = 0

while True:
    ret, frame = video.read()

    if not ret:
        break

    frame_name = f"{OUTPUT_DIR}/frame_{count:04d}.png"

    cv2.imwrite(frame_name, frame)

    print(f"[+] Saved {frame_name}")

    count += 1

video.release()

print(f"[+] Total frames extracted: {count}")

