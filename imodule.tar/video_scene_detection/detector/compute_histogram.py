import cv2
import os
import numpy as np

INPUT_DIR = "gray_frames"
OUTPUT_DIR = "histograms"

os.makedirs(OUTPUT_DIR, exist_ok=True)

files = sorted(os.listdir(INPUT_DIR))

for file in files:

    if not file.endswith(".png"):
        continue

    img_path = os.path.join(INPUT_DIR, file)

    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    hist = cv2.calcHist([img], [0], None, [256], [0, 256])

    hist = cv2.normalize(hist, hist).flatten()

    index = file.replace("gray_", "").replace(".png", "")

    out_path = os.path.join(OUTPUT_DIR, f"hist_{index}.npy")

    np.save(out_path, hist)

    print(f"[+] Saved {out_path}")

print("[+] Histogram calculation completed")
