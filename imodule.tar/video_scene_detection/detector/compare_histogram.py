import os
import numpy as np

HIST_DIR = "histograms"
OUTPUT_FILE = "results/histogram_differences.txt"

os.makedirs("results", exist_ok=True)

files = sorted([
    f for f in os.listdir(HIST_DIR)
    if f.endswith(".npy")
])

if len(files) < 2:
    print("[-] Not enough histogram files")
    exit(1)

with open(OUTPUT_FILE, "w") as out:

    for i in range(1, len(files)):

        prev_hist = np.load(
            os.path.join(HIST_DIR, files[i - 1])
        )

        curr_hist = np.load(
            os.path.join(HIST_DIR, files[i])
        )

        diff = np.sum(
            np.abs(prev_hist - curr_hist)
        )

        frame_name = f"frame_{i:04d}.png"

        line = f"{frame_name} {diff:.6f}"

        print(line)

        out.write(line + "\n")

print(f"[+] Saved differences to {OUTPUT_FILE}")
